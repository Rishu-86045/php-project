<!DOCTYPE html>
<html lang="en">
<head>
    <title>Job Application Form</title>
    <?php include 'C:\xampp\htdocs\pro\links.php'; ?>
    <?php include 'C:\xampp\htdocs\pro\connection.php'; ?>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f4f4f9;
        }

        .container {
            display: flex;
            width: 80%;
            max-width: 900px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            overflow: hidden;
        }

        .left {
            width: 35%;
            padding: 20px;
            background: linear-gradient(135deg, #004aad, #00c6ff);
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
        }

        .left h2 {
            font-size: 24px;
            margin-bottom: 10px;
        }

        .left p {
            font-size: 14px;
            margin-bottom: 20px;
        }

        .left button {
            background-color: white;
            color: #004aad;
            border: none;
            padding: 10px 20px;
            border-radius: 20px;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s;
        }

        .left button:hover {
            background-color: #e6e6e6;
        }

        .right {
            width: 65%;
            padding: 40px;
        }

        .right h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
            font-size: 22px;
        }

        .form-group {
            display: flex;
            justify-content: space-between;
            gap: 10px;
            margin-bottom: 15px;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .form-group input[type="submit"] {
            width: 100%;
            background-color: #004aad;
            color: white;
            border: none;
            padding: 12px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background 0.3s;
        }

        .form-group input[type="submit"]:hover {
            background-color: #003280;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="left">
        <h2>Welcome</h2>
        <p>Please fill all the details carefully. This form can change your life.</p>
        <button>Check Form</button>
    </div>

    <div class="right">
        <h2>Apply for Web Developer Post</h2>
        <form action="" method="post">

        <?php 
            // Fetching the existing data for the given ID
            $ids = $_GET['id'];
            $showquery = "SELECT * FROM rishu WHERE id={$ids}";
            $showdata = mysqli_query($con, $showquery);
            $arrdata = mysqli_fetch_array($showdata);

            // Updating the data if the form is submitted
            if (isset($_POST['submit'])) {
                $Name = mysqli_real_escape_string($con, $_POST['Name']);
                $degree = mysqli_real_escape_string($con, $_POST['degree']);
                $mobile = mysqli_real_escape_string($con, $_POST['mobile']);
                $email = mysqli_real_escape_string($con, $_POST['email']);
                $refer = mysqli_real_escape_string($con, $_POST['refer']);
                $post = mysqli_real_escape_string($con, $_POST['post']);

                // Update query
                $query = "UPDATE rishu SET Name='$Name', degree='$degree', mobile='$mobile', email='$email', refer='$refer', post='$post' WHERE id=$ids";
                $res = mysqli_query($con, $query);

                if ($res) {
                    echo "<script>alert('Data updated successfully');</script>";
                    // Refreshing the page to show updated values
                    echo "<script>window.location.href = window.location.href;</script>";
                } else {
                    echo "<script>alert('Data not updated properly');</script>";
                }
            }
        ?>

            <!-- Form fields pre-filled with existing data -->
            <div class="form-group">
                <input type="text" name="Name" value="<?php echo htmlspecialchars($arrdata['Name']); ?>" placeholder="Enter your name *" required>
                <input type="text" name="degree" value="<?php echo htmlspecialchars($arrdata['degree']); ?>" placeholder="Enter your qualification *" required>
            </div>
            <div class="form-group">
                <input type="tel" name="mobile" value="<?php echo htmlspecialchars($arrdata['mobile']); ?>" placeholder="Mobile number *" required>
                <input type="email" name="email" value="<?php echo htmlspecialchars($arrdata['email']); ?>" placeholder="Email ID *" required>
            </div>
            <div class="form-group">
                <input type="text" name="refer" value="<?php echo htmlspecialchars($arrdata['refer']); ?>" placeholder="Any references *" required>
                <input type="text" name="post" value="<?php echo htmlspecialchars($arrdata['post']); ?>" placeholder="Web Developer *" required>
            </div>
            <div class="form-group">
                <input type="submit" name="submit" value="Update">
            </div>
        </form>
    </div>
</div>

</body>
</html>

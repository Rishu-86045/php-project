<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Responsive Table Example</title>

    <!-- Link to Font Awesome for icons (add this to links.php or directly here if needed) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        /* General styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f8ff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .table-container {
            width: 90%;
            max-width: 800px;
            background: linear-gradient(to bottom, #42a5f5, #1e88e5);
            border-radius: 8px;
            overflow: hidden;
            margin-top: 20px;
            color: white;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #2196f3;
            font-weight: bold;
        }

        td {
            background-color: rgba(255, 255, 255, 0.1);
        }

        /* Icon styling */
        .operation-icons {
            font-size: 20px;
            cursor: pointer;
        }
        
        .edit-icon {
            color: #4caf50;
            margin-right: 8px;
        }

        .delete-icon {
            color: #f44336;
        }

        /* Responsive Adjustments */
        @media (max-width: 768px) {
            th, td {
                padding: 8px;
                font-size: 14px;
            }
        }

        /* Card-style table for very small screens */
        @media (max-width: 480px) {
            table, thead, tbody, th, td, tr {
                display: block;
            }

            th {
                display: none; /* Hide headers in card view */
            }

            td {
                display: flex;
                justify-content: space-between;
                padding: 8px 10px;
                border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            }

            /* Show column name before each cell value */
            td:before {
                content: attr(data-label);
                font-weight: bold;
                text-transform: uppercase;
                flex-basis: 50%;
                color: #b3e5fc;
            }
        }
    </style>
</head>
<body>

<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>NAME</th>
                <th>DEGREE</th>
                <th>MOBILE</th>
                <th>EMAIL</th>
                <th>REFER</th>
                <th>POST</th>
                <th>OPERATION</th>
            </tr>
        </thead>
        <tbody>
            <?php
                include 'connection.php';

                $selectquery = "SELECT * FROM rishu";
                $query = mysqli_query($con, $selectquery);

                while($res = mysqli_fetch_array($query)) {
            ?>
                <tr>
                    <td data-label="ID"><?php echo $res['id']; ?></td>
                    <td data-label="NAME"><?php echo $res['Name']; ?></td>
                    <td data-label="DEGREE"><?php echo $res['degree']; ?></td>
                    <td data-label="MOBILE"><?php echo $res['mobile']; ?></td>
                    <td data-label="EMAIL"><?php echo $res['email']; ?></td>
                    <td data-label="REFER"><?php echo $res['refer']; ?></td>
                    <td data-label="POST"><?php echo $res['post']; ?></td>
                    <td data-label="OPERATION">
                        <i class="fas fa-edit edit-icon"></i>
                        <i class="fas fa-trash delete-icon"></i>
                    </td>
                </tr>
            <?php
                }
            ?>
        </tbody>
    </table>
</div>

</body>
</html>

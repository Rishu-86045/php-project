






<!DOCTYPE html>
<html lang="en">
<head>
<title>Table Example</title>
<?php include 'C:\xampp\htdocs\pro\links.php'  ?>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f0f8ff;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
    }
    .table-container {
        width: 100%;
        background: linear-gradient(to bottom, #42a5f5, #1e88e5);
        border-radius: 8px;
        overflow: hidden;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        color: white;
    }
    th, td {
        padding: 12px;
        text-align: left;
    }
    th {
        background-color: #2196f3;
        font-weight: bold;
    }
    td {
        background-color: rgba(255, 255, 255, 0.1);
    }
    .operation-icons {
        font-size: 20px;
        cursor: pointer;
    }
    .edit-icon {
        color: #4caf50;
    }
    .delete-icon {
        color: #f44336;
        margin-left: 8px;
    }
    .t {
        background-color: #929fb1;
        color: black;
    }



/* Responsive adjustments */
@media (max-width: 768px) {
        th, td {
            padding: 8px;
            font-size: 14px;
        }
    }

    /* Stack table into a card view on very small screens */
    @media (max-width: 480px) {
        table, thead, tbody, th, td, tr {
            display: block;
        }
        th {
            display: none; /* Hide header in card view */
        }
        td {
            display: flex;
            justify-content: space-between;
            padding: 8px 10px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        }
        td:before {
            content: attr(data-label); /* Add labels to cells */
            font-weight: bold;
            text-transform: uppercase;
            flex-basis: 50%;
            color: #b3e5fc;
        }
    }
    




</style>
</head>
<body>
<div class="m">
    <h3>List of candidates for web developer job</h3>
    <div class="table-container">
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>NAME</th>
                <th>DEGREE</th>
                <th>MOBILE</th>
                <th>EMAIL</th>
                <th>REFER</th>
                <th>POST</th>
                <th>OPERATION</th>
            </tr>
        </thead>
        <tbody>




        <?php
                include 'connection.php';

                $selectquery = " select * from rishu ";

                $query = mysqli_query($con,$selectquery);


                $nums = mysqli_num_rows($query);


                while($res = mysqli_fetch_array($query)){

                    ?>


                    <tr class="t">
                <td><?php  echo $res['id']; ?></td>
                <td><?php  echo $res['Name']; ?></td>
                <td><?php  echo $res['degree']; ?></td>
                <td><?php  echo $res['mobile']; ?></td>
                <td><?php  echo $res['email']; ?></td>
                <td><?php  echo $res['refer']; ?></td>
                <td><?php  echo $res['post']; ?></td>
                <td>
                <a href="updates.php?id=<?php echo $res['id']; ?>" data-toggle="tooltip" data-placement="bottom" title="UPDATE!">
                <i class="fa fa-edit" aria-hidden="true"></i></a>
                </td>
                <td>
                <a href="delete.php?id=<?php echo $res['id']; ?>" data-toggle="tooltip" data-placement="bottom" title="DELETE!">
                <i class="fa fa-trash" aria-hidden="true"></i></a>
                </td>
            </tr>



                <?php
                }
                //echo $res['Name'];

                ?>


        
            
        </tbody>
    </table>
    </div>
</div>

</body>
</html>

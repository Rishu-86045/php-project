<?php
include 'C:\xampp\htdocs\pro\connection.php';

$id = $_GET['id'];
$deletequery = "DELETE FROM rishu WHERE id=$id";
$query = mysqli_query($con, $deletequery);
if($query){
    ?>
        <script>alert("Deleted Successfully");</script>
    <?php
}else{
    ?>
        <script>alert("Not Deleted");</script>
    <?php
}

header('Location: display.php');
exit(); // It’s good practice to use exit() after header redirection
?>
